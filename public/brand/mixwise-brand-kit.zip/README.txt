MixWise Brand Kit
=================

Approved assets for press, partners, and product use.

Lockups (prefer SVG)
- mixwise-lockup.svg          Forest on transparent (default / light backgrounds)
- mixwise-lockup-cream.svg    Cream on transparent (dark backgrounds)
- mixwise-lockup-olive.svg    Olive on transparent (optional accent surface)

PNG lockups are included for tools that do not accept SVG.

App icon
- mixwise-app-icon.svg / .png

Standalone mark
- mixwise-lime-wheel-vector.svg  Lime wheel only (favicon / app mark — not a substitute for the wordmark)

Usage
- Do not recreate the lockup from system fonts + a separate lime.
- Do not stretch, recolor, or add effects to the lockup.
- Clear space: keep the mark free of competing logos and dense UI chrome.
- Name: MixWise (capital M and W). URL: getmixwise.com

Questions: hello@getmixwise.com
